import 'package:flutter/material.dart';

import '../controllers/profile_controller.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() {
    return _ProfileScreenState();
  }
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final ProfileController _controller;

  static const Color backgroundColour = Color(0xffF6F7FB);
  static const Color primaryColour = Color(0xff4F46E5);
  static const Color cardColour = Colors.white;
  static const Color titleTextColour = Color(0xff111827);
  static const Color subtitleTextColour = Color(0xff6B7280);
  static const Color redColour = Color(0xffEF4444);
  static const Color greenColour = Color(0xff10B981);

  @override
  void initState() {
    super.initState();

    _controller = ProfileController();
    _controller.start();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String _firstLetter(String text) {
    final trimmedText = text.trim();

    if (trimmedText.isEmpty) {
      return '?';
    }

    return trimmedText[0].toUpperCase();
  }

  String _limitedUsername(String text) {
    final trimmedText = text.trim();

    if (trimmedText.length > 15) {
      return '${trimmedText.substring(0, 14)}…';
    }

    return trimmedText;
  }

  String _cleanError(Object error) {
    return error.toString().replaceFirst('Exception: ', '');
  }

  void _showMessage(
    String message, {
    bool isError = false,
    Color? backgroundColor,
    Color? textColor,
  }) {
    ScaffoldMessenger.of(context).clearSnackBars();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor:
            backgroundColor ?? (isError ? redColour : primaryColour),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        content: Text(
          message,
          style: TextStyle(
            color: textColor ?? Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Future<void> _changeUsername() async {
    final usernameController = TextEditingController(
      text: _controller.profile.username,
    );

    String? usernameError;

    final newUsername = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              contentPadding: const EdgeInsets.all(24),
              content: SizedBox(
                width: 380,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _dialogHeader(
                      icon: Icons.person_outline_rounded,
                      title: 'Change Username',
                      subtitle: 'Enter a new username for your profile.',
                    ),

                    const SizedBox(height: 24),

                    _inputLabel('Username'),
                    TextField(
                      controller: usernameController,
                      maxLength: 30,
                      onChanged: (_) {
                        if (usernameError != null) {
                          setDialogState(() {
                            usernameError = null;
                          });
                        }
                      },
                      decoration: _inputDecoration(
                        'Enter new username',
                        customBorderColor:
                            usernameError != null ? redColour : null,
                        prefixIcon: Icon(
                          Icons.person_outline_rounded,
                          color: usernameError != null
                              ? redColour
                              : Colors.grey.shade500,
                          size: 20,
                        ),
                      ),
                    ),

                    _fieldError(usernameError),

                    const SizedBox(height: 24),

                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 48,
                            child: OutlinedButton(
                              onPressed: () {
                                      Navigator.pop(dialogContext);
                                    },
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(color: Colors.grey.shade300),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text(
                                'Cancel',
                                style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: SizedBox(
                            height: 48,
                            child: ElevatedButton(
                              onPressed: () {
                                      final value =
                                          usernameController.text.trim();

                                      if (value.isEmpty) {
                                        setDialogState(() {
                                          usernameError =
                                              'Please enter a username.';
                                        });
                                        return;
                                      }

                                      Navigator.pop(dialogContext, value);
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColour,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 0,
                              ),
                              child: const Text(
                                'Save',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    usernameController.dispose();

    if (newUsername == null) {
      return;
    }

    try {
      await _controller.changeUsername(newUsername);

      if (!mounted) return;

      _showMessage(
        'Username updated successfully',
        backgroundColor: greenColour,
        textColor: Colors.white,
      );
    } catch (error) {
      if (!mounted) return;

      _showMessage(
        _cleanError(error),
        isError: true,
      );
    }
  }

  Future<void> _changePassword() async {
    final emailController = TextEditingController();

    String? emailError;

    final email = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              contentPadding: const EdgeInsets.all(24),
              content: SizedBox(
                width: 380,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _dialogHeader(
                      icon: Icons.lock_reset_rounded,
                      title: 'Reset Password',
                      subtitle:
                          'Enter your email address to receive a password reset link.',
                    ),

                    const SizedBox(height: 24),

                    _inputLabel('Email Address'),
                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      onChanged: (_) {
                        if (emailError != null) {
                          setDialogState(() {
                            emailError = null;
                          });
                        }
                      },
                      decoration: _inputDecoration(
                        'Enter your email',
                        customBorderColor:
                            emailError != null ? redColour : null,
                        prefixIcon: Icon(
                          Icons.email_outlined,
                          color: emailError != null
                              ? redColour
                              : Colors.grey.shade500,
                          size: 20,
                        ),
                      ),
                    ),

                    _fieldError(emailError),

                    const SizedBox(height: 24),

                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 48,
                            child: OutlinedButton(
                              onPressed: () {
                                      Navigator.pop(dialogContext);
                                    },
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(color: Colors.grey.shade300),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text(
                                'Cancel',
                                style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: SizedBox(
                            height: 48,
                            child: ElevatedButton(
                              onPressed: () {
                                      final value =
                                          emailController.text.trim();

                                      if (value.isEmpty) {
                                        setDialogState(() {
                                          emailError =
                                              'Please enter your email address.';
                                        });
                                        return;
                                      }

                                      if (!RegExp(
                                        r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                                      ).hasMatch(value)) {
                                        setDialogState(() {
                                          emailError =
                                              'Please enter a valid email address.';
                                        });
                                        return;
                                      }

                                      Navigator.pop(dialogContext, value);
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColour,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 0,
                              ),
                              child: const Text(
                                'Send Link',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    emailController.dispose();

    if (email == null) {
      return;
    }

    try {
      await _controller.sendPasswordResetEmail(email);

      if (!mounted) return;

      _showMessage(
        'Password reset email sent. Please check your inbox.',
        backgroundColor: greenColour,
        textColor: Colors.white,
      );
    } catch (error) {
      if (!mounted) return;

      _showMessage(
        _cleanError(error),
        isError: true,
      );
    }
  }

  Future<void> _changeEmail() async {
    final newEmailController = TextEditingController();
    final currentPasswordController = TextEditingController();

    String? newEmailError;
    String? passwordError;

    final result = await showDialog<Map<String, String>>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              contentPadding: const EdgeInsets.all(24),
              content: SizedBox(
                width: 380,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _dialogHeader(
                      icon: Icons.email_outlined,
                      title: 'Change Email',
                      subtitle:
                          'Enter your new email and current password to verify this change.',
                    ),

                    const SizedBox(height: 24),

                    _inputLabel('New Email Address'),
                    TextField(
                      controller: newEmailController,
                      keyboardType: TextInputType.emailAddress,
                      onChanged: (_) {
                        if (newEmailError != null) {
                          setDialogState(() {
                            newEmailError = null;
                          });
                        }
                      },
                      decoration: _inputDecoration(
                        'Enter your new email',
                        customBorderColor:
                            newEmailError != null ? redColour : null,
                        prefixIcon: Icon(
                          Icons.email_outlined,
                          color: newEmailError != null
                              ? redColour
                              : Colors.grey.shade500,
                          size: 20,
                        ),
                      ),
                    ),

                    _fieldError(newEmailError),

                    const SizedBox(height: 16),

                    _inputLabel('Current Password'),
                    TextField(
                      controller: currentPasswordController,
                      obscureText: true,
                      onChanged: (_) {
                        if (passwordError != null) {
                          setDialogState(() {
                            passwordError = null;
                          });
                        }
                      },
                      decoration: _inputDecoration(
                        'Enter your current password',
                        customBorderColor:
                            passwordError != null ? redColour : null,
                        prefixIcon: Icon(
                          Icons.lock_outline_rounded,
                          color: passwordError != null
                              ? redColour
                              : Colors.grey.shade500,
                          size: 20,
                        ),
                      ),
                    ),

                    _fieldError(passwordError),

                    const SizedBox(height: 24),

                    Row(
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 48,
                            child: OutlinedButton(
                              onPressed: () {
                                      Navigator.pop(dialogContext);
                                    },
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(color: Colors.grey.shade300),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text(
                                'Cancel',
                                style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: SizedBox(
                            height: 48,
                            child: ElevatedButton(
                              onPressed: () {
                                      final newEmail =
                                          newEmailController.text.trim();
                                      final currentPassword =
                                          currentPasswordController.text.trim();

                                      bool hasError = false;

                                      if (newEmail.isEmpty) {
                                        newEmailError =
                                            'Please enter your new email address.';
                                        hasError = true;
                                      } else if (!RegExp(
                                        r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                                      ).hasMatch(newEmail)) {
                                        newEmailError =
                                            'Please enter a valid email address.';
                                        hasError = true;
                                      }

                                      if (currentPassword.isEmpty) {
                                        passwordError =
                                            'Please enter your current password.';
                                        hasError = true;
                                      }

                                      if (hasError) {
                                        setDialogState(() {});
                                        return;
                                      }

                                      Navigator.pop(dialogContext, {
                                        'newEmail': newEmail,
                                        'currentPassword': currentPassword,
                                      });
                                    },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColour,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                elevation: 0,
                              ),
                              child: const Text(
                                'Save',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    newEmailController.dispose();
    currentPasswordController.dispose();

    if (result == null) {
      return;
    }

    try {
      await _controller.changeEmail(
        newEmail: result['newEmail']!,
        currentPassword: result['currentPassword']!,
      );

      if (!mounted) return;

      _showMessage(
        'Verification email sent. After verifying, log in again to sync your email.',
        backgroundColor: greenColour,
        textColor: Colors.white,
      );
    } catch (error) {
      if (!mounted) return;

      _showMessage(
        _cleanError(error),
        isError: true,
      );
    }
  }

  Future<void> _logout() async {
    await _controller.logout();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        if (_controller.isLoading) {
          return const Scaffold(
            backgroundColor: backgroundColour,
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (_controller.errorMessage != null) {
          return Scaffold(
            backgroundColor: backgroundColour,
            body: Center(
              child: Text(_controller.errorMessage!),
            ),
          );
        }

        final profile = _controller.profile;
        final displayUsername = _limitedUsername(profile.username);
        final profileLetter = _firstLetter(profile.username);

        return Scaffold(
          backgroundColor: backgroundColour,
          appBar: AppBar(
            backgroundColor: backgroundColour,
            elevation: 0,
            centerTitle: true,
            automaticallyImplyLeading: false,
            title: const Text(
              'Profile',
              style: TextStyle(
                color: titleTextColour,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildProfileHeader(
                  profileLetter: profileLetter,
                  displayUsername: displayUsername,
                  email: profile.email,
                ),
                const SizedBox(height: 26),
                const Text(
                  'Settings',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: titleTextColour,
                  ),
                ),
                const SizedBox(height: 12),
                _buildSettingsCard(),
                const SizedBox(height: 24),
                _buildLogoutButton(),
              ],
            ),
          ),
        );
      },
    );
  }

  InputDecoration _inputDecoration(
    String hintText, {
    Widget? prefixIcon,
    Widget? suffixIcon,
    Color? customBorderColor,
  }) {
    final borderSide = customBorderColor != null
        ? BorderSide(color: customBorderColor, width: 1.5)
        : BorderSide(color: Colors.grey.shade300);

    final focusedSide = customBorderColor != null
        ? BorderSide(color: customBorderColor, width: 2.0)
        : const BorderSide(color: primaryColour, width: 1.5);

    return InputDecoration(
      hintText: hintText,
      filled: true,
      fillColor: Colors.white,
      prefixIcon: prefixIcon,
      suffixIcon: suffixIcon,
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 14,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: borderSide,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: borderSide,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: focusedSide,
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(
          color: Colors.grey.shade300,
        ),
      ),
    );
  }

  Widget _inputLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 13,
        ),
      ),
    );
  }

  Widget _fieldError(String? errorText) {
    if (errorText == null) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.only(top: 6, left: 2),
      child: Row(
        children: [
          const Icon(
            Icons.error_outline_rounded,
            size: 14,
            color: redColour,
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              errorText,
              style: const TextStyle(
                fontSize: 12,
                color: redColour,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dialogHeader({
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: primaryColour.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: primaryColour,
              size: 36,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: titleTextColour,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey.shade600,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileHeader({
    required String profileLetter,
    required String displayUsername,
    required String email,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cardColour,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 34,
            backgroundColor: primaryColour.withValues(alpha: 0.15),
            child: Text(
              profileLetter,
              style: const TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                color: primaryColour,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  displayUsername,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: titleTextColour,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  email,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    color: subtitleTextColour,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsCard() {
    final profile = _controller.profile;

    return Container(
      decoration: BoxDecoration(
        color: cardColour,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          ListTile(
            leading: const Icon(
              Icons.notifications_none_rounded,
              color: primaryColour,
            ),
            title: const Text(
              'Notifications',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: titleTextColour,
              ),
            ),
            trailing: Switch(
              value: profile.notificationsEnabled,
              activeThumbColor: primaryColour,
              activeTrackColor: primaryColour.withValues(alpha: 0.35),
              onChanged: (value) async {
                try {
                  await _controller.updateNotifications(value);
                } catch (error) {
                  if (!mounted) return;

                  _showMessage(
                    _cleanError(error),
                    isError: true,
                  );
                }
              },
            ),
          ),
          const Divider(height: 1),
          _buildSettingsTile(
            icon: Icons.person_outline_rounded,
            title: 'Change Username',
            onTap: _changeUsername,
          ),
          const Divider(height: 1),
          _buildSettingsTile(
            icon: Icons.lock_outline_rounded,
            title: 'Reset Password',
            onTap: _changePassword,
          ),
          const Divider(height: 1),
          _buildSettingsTile(
            icon: Icons.email_outlined,
            title: 'Change Email',
            onTap: _changeEmail,
          ),
          const Divider(height: 1),
          _buildSortingDropdown(),
        ],
      ),
    );
  }

  Widget _buildSettingsTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Icon(
        icon,
        color: primaryColour,
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          color: titleTextColour,
        ),
      ),
      trailing: const Icon(
        Icons.chevron_right_rounded,
        color: subtitleTextColour,
      ),
    );
  }

  Widget _buildSortingDropdown() {
    final profile = _controller.profile;

    return ListTile(
      leading: const Icon(
        Icons.sort_rounded,
        color: primaryColour,
      ),
      title: const Text(
        'Default Task Sorting',
        style: TextStyle(
          fontWeight: FontWeight.w600,
          color: titleTextColour,
        ),
      ),
      trailing: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: profile.defaultTaskSorting,
          borderRadius: BorderRadius.circular(12),
          items: ProfileController.sortingOptions.map((option) {
            return DropdownMenuItem<String>(
              value: option,
              child: Text(
                option,
                style: const TextStyle(
                  fontSize: 13,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) async {
            if (value == null) {
              return;
            }

            try {
              await _controller.updateDefaultSorting(value);
            } catch (error) {
              if (!mounted) return;

              _showMessage(
                _cleanError(error),
                isError: true,
              );
            }
          },
        ),
      ),
    );
  }

  Widget _buildLogoutButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: OutlinedButton.icon(
        onPressed: _logout,
        icon: const Icon(Icons.logout_rounded),
        label: const Text(
          'Logout',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: redColour,
          side: const BorderSide(
            color: redColour,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }
}