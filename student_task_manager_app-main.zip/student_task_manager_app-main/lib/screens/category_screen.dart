import 'package:flutter/material.dart';

import '../controllers/category_controller.dart';
import '../models/category_model.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() {
    return _CategoryScreenState();
  }
}

class _CategoryScreenState extends State<CategoryScreen> {
  static const Color backgroundColor = Color(0xFFF6F7FB);

  final CategoryController _categoryController =
      CategoryController();

  void _showMessage(String message) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  String _errorMessage(Object error) {
    if (error is CategoryControllerException) {
      return error.message;
    }

    return 'An unexpected error occurred.';
  }

  IconData _iconFromKey(String iconKey) {
    switch (iconKey) {
      case 'phone':
        return Icons.phone_android_rounded;

      case 'database':
        return Icons.storage_rounded;

      case 'code':
        return Icons.code_rounded;

      case 'school':
        return Icons.school_rounded;

      default:
        return Icons.more_horiz_rounded;
    }
  }

  Future<void> _showAddCategoryDialog() async {
    final TextEditingController textController =
        TextEditingController();

    bool isSaving = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            Future<void> saveCategory() async {
              if (isSaving) {
                return;
              }

              setDialogState(() {
                isSaving = true;
              });

              try {
                final String categoryName =
                    textController.text.trim();

                await _categoryController.addCategory(
                  categoryName,
                );

                if (!dialogContext.mounted) {
                  return;
                }

                Navigator.pop(dialogContext);
                _showMessage(
                  '$categoryName was added.',
                );
              } catch (error) {
                _showMessage(_errorMessage(error));

                if (dialogContext.mounted) {
                  setDialogState(() {
                    isSaving = false;
                  });
                }
              }
            }

            return AlertDialog(
              title: const Text('Add Category'),
              content: TextField(
                controller: textController,
                autofocus: true,
                enabled: !isSaving,
                maxLength: 50,
                textCapitalization:
                    TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Category name',
                  hintText:
                      'For example: Software Design',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) {
                  saveCategory();
                },
              ),
              actions: [
                TextButton(
                  onPressed: isSaving
                      ? null
                      : () {
                          Navigator.pop(dialogContext);
                        },
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed:
                      isSaving ? null : saveCategory,
                  child: isSaving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Text('Add'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _showEditCategoryDialog(
    CategoryModel category,
  ) async {
    final TextEditingController textController =
        TextEditingController(
      text: category.name,
    );

    bool isSaving = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            Future<void> updateCategory() async {
              if (isSaving) {
                return;
              }

              final String newName =
                  textController.text.trim();

              if (newName.toLowerCase() ==
                  category.name.trim().toLowerCase()) {
                Navigator.pop(dialogContext);
                return;
              }

              setDialogState(() {
                isSaving = true;
              });

              try {
                await _categoryController.renameCategory(
                  category: category,
                  newName: newName,
                );

                if (!dialogContext.mounted) {
                  return;
                }

                Navigator.pop(dialogContext);

                _showMessage(
                  '${category.name} was renamed to $newName.',
                );
              } catch (error) {
                _showMessage(_errorMessage(error));

                if (dialogContext.mounted) {
                  setDialogState(() {
                    isSaving = false;
                  });
                }
              }
            }

            return AlertDialog(
              title: const Text('Edit Category'),
              content: TextField(
                controller: textController,
                autofocus: true,
                enabled: !isSaving,
                maxLength: 50,
                textCapitalization:
                    TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Category name',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) {
                  updateCategory();
                },
              ),
              actions: [
                TextButton(
                  onPressed: isSaving
                      ? null
                      : () {
                          Navigator.pop(dialogContext);
                        },
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed:
                      isSaving ? null : updateCategory,
                  child: isSaving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _confirmDeleteCategory(
    CategoryModel category,
    int taskCount,
  ) async {
    final bool? shouldDelete =
        await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete Category?'),
          content: Text(
            taskCount == 0
                ? 'Delete "${category.name}"?'
                : '"${category.name}" is used by '
                    '$taskCount '
                    '${taskCount == 1 ? 'task' : 'tasks'}. '
                    'A category that is currently in use '
                    'cannot be deleted.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: Text(
                taskCount == 0 ? 'Cancel' : 'Close',
              ),
            ),
            if (taskCount == 0)
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.red,
                ),
                onPressed: () {
                  Navigator.pop(dialogContext, true);
                },
                child: const Text('Delete'),
              ),
          ],
        );
      },
    );

    if (shouldDelete != true) {
      return;
    }

    try {
      await _categoryController.deleteCategory(
        category: category,
        taskCount: taskCount,
      );

      _showMessage(
        '${category.name} was deleted.',
      );
    } catch (error) {
      _showMessage(_errorMessage(error));
    }
  }

  void _showCategoryOptions(
    CategoryModel category,
    int taskCount,
  ) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (bottomSheetContext) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading:
                    const Icon(Icons.edit_outlined),
                title:
                    const Text('Edit category'),
                onTap: () {
                  Navigator.pop(bottomSheetContext);

                  _showEditCategoryDialog(category);
                },
              ),
              ListTile(
                leading: const Icon(
                  Icons.delete_outline,
                  color: Colors.red,
                ),
                title: const Text(
                  'Delete category',
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
                onTap: () {
                  Navigator.pop(bottomSheetContext);

                  _confirmDeleteCategory(
                    category,
                    taskCount,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.category_outlined,
            size: 54,
            color: Colors.grey,
          ),
          const SizedBox(height: 12),
          const Text(
            'No categories yet',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Create your first category to organise tasks.',
            style: TextStyle(
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _showAddCategoryDialog,
            icon: const Icon(Icons.add),
            label: const Text('Add Category'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isAuthenticated =
        _categoryController.isAuthenticated;

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: const Text(
          'Categories',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            onPressed: isAuthenticated
                ? _showAddCategoryDialog
                : null,
            icon: const Icon(
              Icons.add_rounded,
              color: Colors.black,
            ),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: !isAuthenticated
          ? const Center(
              child: Text(
                'Please log in to manage categories.',
              ),
            )
          : StreamBuilder<List<CategoryModel>>(
              stream:
                  _categoryController.categoriesStream,
              builder: (context, categorySnapshot) {
                if (categorySnapshot.hasError) {
                  return Center(
                    child: Text(
                      'Unable to load categories: '
                      '${categorySnapshot.error}',
                      textAlign: TextAlign.center,
                    ),
                  );
                }

                if (categorySnapshot.connectionState ==
                    ConnectionState.waiting) {
                  return const Center(
                    child:
                        CircularProgressIndicator(),
                  );
                }

                final List<CategoryModel> categories =
                    categorySnapshot.data ??
                        const <CategoryModel>[];

                return StreamBuilder<Map<String, int>>(
                  stream:
                      _categoryController.taskCountsStream,
                  builder: (context, taskCountSnapshot) {
                    if (taskCountSnapshot.hasError) {
                      return Center(
                        child: Text(
                          'Unable to load task counts: '
                          '${taskCountSnapshot.error}',
                          textAlign: TextAlign.center,
                        ),
                      );
                    }

                    if (taskCountSnapshot
                            .connectionState ==
                        ConnectionState.waiting) {
                      return const Center(
                        child:
                            CircularProgressIndicator(),
                      );
                    }

                    final Map<String, int> taskCounts =
                        taskCountSnapshot.data ??
                            const <String, int>{};

                    if (categories.isEmpty) {
                      return _buildEmptyState();
                    }

                    return ListView.separated(
                      padding:
                          const EdgeInsets.fromLTRB(
                        16,
                        12,
                        16,
                        24,
                      ),
                      itemCount: categories.length,
                      separatorBuilder:
                          (context, index) {
                        return const SizedBox(
                          height: 12,
                        );
                      },
                      itemBuilder: (context, index) {
                        final CategoryModel category =
                            categories[index];

                        final int taskCount =
                            taskCounts[category.name] ??
                                0;

                        return CategoryCard(
                          category: category,
                          taskCount: taskCount,
                          icon: _iconFromKey(
                            category.iconKey,
                          ),
                          onMorePressed: () {
                            _showCategoryOptions(
                              category,
                              taskCount,
                            );
                          },
                        );
                      },
                    );
                  },
                );
              },
            ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  final CategoryModel category;
  final int taskCount;
  final IconData icon;
  final VoidCallback onMorePressed;

  const CategoryCard({
    super.key,
    required this.category,
    required this.taskCount,
    required this.icon,
    required this.onMorePressed,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      elevation: 1,
      shadowColor: Colors.black12,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: Color(category.colorValue),
                borderRadius:
                    BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                color: Colors.white,
                size: 25,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    category.name,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1F2937),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$taskCount '
                    '${taskCount == 1 ? 'Task' : 'Tasks'}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF6B7280),
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              onPressed: onMorePressed,
              icon: const Icon(
                Icons.more_vert_rounded,
                color: Color(0xFF6B7280),
              ),
            ),
          ],
        ),
      ),
    );
  }
}