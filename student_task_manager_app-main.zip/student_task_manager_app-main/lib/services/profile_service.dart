import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/profile_model.dart';

class ProfileService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? get currentUser {
    return _auth.currentUser;
  }

  Stream<ProfileModel> watchCurrentUserProfile() {
    final user = _auth.currentUser;

    if (user == null) {
      return Stream.error(Exception('No logged-in user found'));
    }

    return _firestore
        .collection('userdata')
        .doc(user.uid)
        .snapshots()
        .map((snapshot) {
      final data = snapshot.data() ?? {};

      return ProfileModel.fromMap(
        data: data,
        uid: user.uid,
        fallbackEmail: user.email ?? '',
      );
    });
  }

  Future<void> updateCurrentUserData(
    Map<String, dynamic> updatedData,
  ) async {
    final user = _auth.currentUser;

    if (user == null) {
      throw Exception('No logged-in user found');
    }

    await _firestore.collection('userdata').doc(user.uid).set(
      {
        ...updatedData,
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<void> sendPasswordResetEmail(String email) async {
    await _auth.sendPasswordResetEmail(
      email: email,
    );
  }

  Future<void> reauthenticateCurrentUser(String currentPassword) async {
    final user = _auth.currentUser;

    if (user == null || user.email == null) {
      throw FirebaseAuthException(
        code: 'no-current-user',
        message: 'No logged-in user found',
      );
    }

    final credential = EmailAuthProvider.credential(
      email: user.email!,
      password: currentPassword,
    );

    await user.reauthenticateWithCredential(credential);
  }

  Future<void> verifyBeforeUpdateEmail(String newEmail) async {
    final user = _auth.currentUser;

    if (user == null) {
      throw FirebaseAuthException(
        code: 'no-current-user',
        message: 'No logged-in user found',
      );
    }

    await user.verifyBeforeUpdateEmail(newEmail);
  }

  Future<void> syncEmailFromAuth() async {
    final oldUser = _auth.currentUser;

    if (oldUser == null) {
      return;
    }

    await oldUser.reload();

    final refreshedUser = _auth.currentUser;
    final authEmail = refreshedUser?.email;

    if (refreshedUser == null || authEmail == null || authEmail.isEmpty) {
      return;
    }

    await _firestore.collection('userdata').doc(refreshedUser.uid).set(
      {
        'email': authEmail,
        'pendingEmail': FieldValue.delete(),
        'updatedAt': FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  Future<void> logout() async {
    await _auth.signOut();
  }

  Future<bool> isUsernameTaken(String username) async {
    final currentUser = _auth.currentUser;

    if (currentUser == null) {
      throw Exception('No authenticated user');
    }

    final newUsername = username.trim();

    final result = await _firestore
        .collection('userdata')
        .where(
          'username',
          isEqualTo: newUsername,
        )
        .limit(2)
        .get();

    return result.docs.any(
      (document) => document.id != currentUser.uid,
    );
  }
}