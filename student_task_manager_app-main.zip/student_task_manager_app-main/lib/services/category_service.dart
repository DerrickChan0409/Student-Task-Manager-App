import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/category_model.dart';

class CategoryService {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  CategoryService({
    FirebaseFirestore? firestore,
    FirebaseAuth? auth,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _auth = auth ?? FirebaseAuth.instance;

  CollectionReference<Map<String, dynamic>>
      get _categoriesCollection {
    return _firestore.collection('categories');
  }

  CollectionReference<Map<String, dynamic>>
      get _tasksCollection {
    return _firestore.collection('tasks');
  }

  String? get currentUserId {
    return _auth.currentUser?.uid;
  }

  bool get isAuthenticated {
    return currentUserId != null;
  }

  String requireUserId() {
    final String? userId = currentUserId;

    if (userId == null) {
      throw FirebaseAuthException(
        code: 'not-authenticated',
        message: 'Please log in before managing categories.',
      );
    }

    return userId;
  }

  Stream<List<CategoryModel>> getCategories() {
    final String? userId = currentUserId;

    if (userId == null) {
      return Stream<List<CategoryModel>>.value(
        const <CategoryModel>[],
      );
    }

    return _categoriesCollection
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt')
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((document) {
        return CategoryModel.fromMap(
          id: document.id,
          data: document.data(),
        );
      }).toList();
    });
  }

  Stream<Map<String, int>> getTaskCounts() {
    final String? userId = currentUserId;

    if (userId == null) {
      return Stream<Map<String, int>>.value(
        const <String, int>{},
      );
    }

    return _tasksCollection
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snapshot) {
      final Map<String, int> taskCounts = {};

      for (final document in snapshot.docs) {
        final String categoryName =
            document.data()['category']?.toString().trim() ?? '';

        if (categoryName.isEmpty) {
          continue;
        }

        taskCounts[categoryName] =
            (taskCounts[categoryName] ?? 0) + 1;
      }

      return taskCounts;
    });
  }

  Future<bool> categoryNameExists(
    String categoryName, {
    String? ignoredCategoryId,
  }) async {
    final String userId = requireUserId();

    final snapshot = await _categoriesCollection
        .where('userId', isEqualTo: userId)
        .get();

    final String normalisedName =
        categoryName.trim().toLowerCase();

    return snapshot.docs.any((document) {
      if (document.id == ignoredCategoryId) {
        return false;
      }

      final String existingName =
          document.data()['name']?.toString().trim().toLowerCase() ??
              '';

      return existingName == normalisedName;
    });
  }

  Future<void> addCategory({
    required String name,
    String iconKey = 'other',
    int colorValue = 0xFF6366F1,
  }) async {
    final String userId = requireUserId();

    await _categoriesCollection.add({
      'userId': userId,
      'name': name,
      'iconKey': iconKey,
      'colorValue': colorValue,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> renameCategoryAndTasks({
    required CategoryModel category,
    required String newName,
  }) async {
    final String userId = requireUserId();

    if (category.userId != userId) {
      throw FirebaseException(
        plugin: 'cloud_firestore',
        code: 'permission-denied',
        message: 'You can only edit your own categories.',
      );
    }

    final taskSnapshot = await _tasksCollection
        .where('userId', isEqualTo: userId)
        .get();

    final matchingTasks = taskSnapshot.docs.where((document) {
      final String taskCategory =
          document.data()['category']?.toString().trim() ?? '';

      return taskCategory == category.name;
    });

    final WriteBatch batch = _firestore.batch();

    batch.update(
      _categoriesCollection.doc(category.id),
      {
        'name': newName,
        'updatedAt': FieldValue.serverTimestamp(),
      },
    );

    for (final task in matchingTasks) {
      batch.update(
        task.reference,
        {
          'category': newName,
          'updatedAt': FieldValue.serverTimestamp(),
        },
      );
    }

    await batch.commit();
  }

  Future<void> deleteCategory(
    CategoryModel category,
  ) async {
    final String userId = requireUserId();

    if (category.userId != userId) {
      throw FirebaseException(
        plugin: 'cloud_firestore',
        code: 'permission-denied',
        message: 'You can only delete your own categories.',
      );
    }

    await _categoriesCollection.doc(category.id).delete();
  }
}