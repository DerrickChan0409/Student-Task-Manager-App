import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/task_model.dart';

class HomeService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<TaskModel>> watchUserTasks(String userId) {
    return _firestore
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .orderBy('dueDate')
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map(TaskModel.fromFirestore).toList();
    });
  }

  Stream<String> watchUsername(String userId) {
    return _firestore
        .collection('userdata')
        .doc(userId)
        .snapshots()
        .map((snapshot) {
      final data = snapshot.data();

      if (data == null) {
        return 'User';
      }

      return data['username']?.toString() ?? 'User';
    });
  }
}