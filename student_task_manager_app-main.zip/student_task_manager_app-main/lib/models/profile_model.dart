class ProfileModel {
  final String uid;
  final String username;
  final String email;
  final bool notificationsEnabled;
  final String defaultTaskSorting;

  const ProfileModel({
    required this.uid,
    required this.username,
    required this.email,
    required this.notificationsEnabled,
    required this.defaultTaskSorting,
  });

  factory ProfileModel.empty() {
    return const ProfileModel(
      uid: '',
      username: 'User',
      email: '',
      notificationsEnabled: true,
      defaultTaskSorting: 'Due Date',
    );
  }

  factory ProfileModel.fromMap({
    required Map<String, dynamic> data,
    required String uid,
    required String fallbackEmail,
  }) {
    return ProfileModel(
      uid: uid,
      username: data['username']?.toString() ?? 'User',
      email: data['email']?.toString() ?? fallbackEmail,
      notificationsEnabled:
          data['notificationsEnabled'] as bool? ?? true,
      defaultTaskSorting:
          data['defaultTaskSorting']?.toString() ?? 'Due Date',
    );
  }

  ProfileModel copyWith({
    String? uid,
    String? username,
    String? email,
    bool? notificationsEnabled,
    String? defaultTaskSorting,
  }) {
    return ProfileModel(
      uid: uid ?? this.uid,
      username: username ?? this.username,
      email: email ?? this.email,
      notificationsEnabled:
          notificationsEnabled ?? this.notificationsEnabled,
      defaultTaskSorting:
          defaultTaskSorting ?? this.defaultTaskSorting,
    );
  }
}