class CategoryModel {
  final String id;
  final String userId;
  final String name;
  final String iconKey;
  final int colorValue;

  const CategoryModel({
    required this.id,
    required this.userId,
    required this.name,
    required this.iconKey,
    required this.colorValue,
  });

  factory CategoryModel.fromMap({
    required String id,
    required Map<String, dynamic> data,
  }) {
    return CategoryModel(
      id: id,
      userId: data['userId']?.toString() ?? '',
      name: data['name']?.toString() ?? 'Unnamed Category',
      iconKey: data['iconKey']?.toString() ?? 'other',
      colorValue: data['colorValue'] is int
          ? data['colorValue'] as int
          : 0xFF9CA3AF,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'name': name,
      'iconKey': iconKey,
      'colorValue': colorValue,
    };
  }

  CategoryModel copyWith({
    String? id,
    String? userId,
    String? name,
    String? iconKey,
    int? colorValue,
  }) {
    return CategoryModel(
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      iconKey: iconKey ?? this.iconKey,
      colorValue: colorValue ?? this.colorValue,
    );
  }
}
