import 'task_model.dart';

class HomeModel {
  final String username;
  final List<TaskModel> tasks;
  final int totalTasks;
  final int completedTasks;
  final int pendingTasks;
  final int overdueTasks;
  final List<TaskModel> recentOverdueTasks;
  final List<TaskModel> recentUpcomingTasks;

  const HomeModel({
    required this.username,
    required this.tasks,
    required this.totalTasks,
    required this.completedTasks,
    required this.pendingTasks,
    required this.overdueTasks,
    required this.recentOverdueTasks,
    required this.recentUpcomingTasks,
  });

  factory HomeModel.empty() {
    return const HomeModel(
      username: 'User',
      tasks: [],
      totalTasks: 0,
      completedTasks: 0,
      pendingTasks: 0,
      overdueTasks: 0,
      recentOverdueTasks: [],
      recentUpcomingTasks: [],
    );
  }
}