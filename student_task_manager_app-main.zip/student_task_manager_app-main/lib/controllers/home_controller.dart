import 'dart:async';

import 'package:flutter/material.dart';

import '../models/home_model.dart';
import '../models/task_model.dart';
import '../services/auth_service.dart';
import '../services/home_service.dart';

class HomeController extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final HomeService _homeService = HomeService();

  StreamSubscription<List<TaskModel>>? _tasksSubscription;
  StreamSubscription<String>? _usernameSubscription;

  Timer? _timer;

  DateTime _now = DateTime.now();
  String _username = 'User';
  List<TaskModel> _tasks = [];

  bool _isLoading = true;
  String? _errorMessage;
  bool _isDisposed = false;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  HomeModel get dashboard {
    final totalTasks = _tasks.length;

    final completedTasks = _tasks.where((task) {
      return task.effectiveStatus(_now) == 'Completed';
    }).length;

    final pendingTasks = _tasks.where((task) {
      return task.effectiveStatus(_now) == 'Pending';
    }).length;

    final overdueTasks = _tasks.where((task) {
      return task.effectiveStatus(_now) == 'Overdue';
    }).length;

    final overdueTaskList = _tasks.where((task) {
      return task.effectiveStatus(_now) == 'Overdue';
    }).toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));

    final upcomingTaskList = _tasks.where((task) {
      return task.effectiveStatus(_now) == 'Pending';
    }).toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));

    return HomeModel(
      username: _username,
      tasks: _tasks,
      totalTasks: totalTasks,
      completedTasks: completedTasks,
      pendingTasks: pendingTasks,
      overdueTasks: overdueTasks,
      recentOverdueTasks: overdueTaskList.take(3).toList(),
      recentUpcomingTasks: upcomingTaskList.take(3).toList(),
    );
  }

  void start() {
    final userId = _authService.currentUserId;

    if (userId == null) {
      _isLoading = false;
      _errorMessage = 'No user is currently logged in.';
      _notify();
      return;
    }

    _listenToUser(userId);
    _listenToTasks(userId);
    _scheduleNextMinuteUpdate();
  }

  void _listenToUser(String userId) {
    _usernameSubscription = _homeService.watchUsername(userId).listen(
      (username) {
        _username = username;
        _notify();
      },
      onError: (error) {
        _errorMessage = 'Unable to load user data: $error';
        _notify();
      },
    );
  }

  void _listenToTasks(String userId) {
    _tasksSubscription = _homeService.watchUserTasks(userId).listen(
      (tasks) {
        _tasks = tasks;
        _isLoading = false;
        _errorMessage = null;
        _notify();
      },
      onError: (error) {
        _isLoading = false;
        _errorMessage = 'Unable to load dashboard: $error';
        _notify();
      },
    );
  }

  void _scheduleNextMinuteUpdate() {
    _timer?.cancel();

    final now = DateTime.now();

    final nextMinute = DateTime(
      now.year,
      now.month,
      now.day,
      now.hour,
      now.minute + 1,
    );

    final delay = nextMinute.difference(now);

    _timer = Timer(delay, () {
      _now = DateTime.now();
      _notify();
      _scheduleNextMinuteUpdate();
    });
  }

  String currentStatus(TaskModel task) {
    return task.effectiveStatus(_now);
  }

  String formatDateTime(DateTime date) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    final hour = date.hour == 0
        ? 12
        : date.hour > 12
            ? date.hour - 12
            : date.hour;

    final minute = date.minute.toString().padLeft(2, '0');
    final period = date.hour >= 12 ? 'PM' : 'AM';

    return '${date.day} ${months[date.month - 1]} ${date.year}, '
        '$hour:$minute $period';
  }

  void _notify() {
    if (!_isDisposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _timer?.cancel();
    _tasksSubscription?.cancel();
    _usernameSubscription?.cancel();
    super.dispose();
  }
}