import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../models/category_model.dart';
import '../services/category_service.dart';

class CategoryControllerException implements Exception {
  final String message;

  const CategoryControllerException(this.message);

  @override
  String toString() {
    return message;
  }
}

class CategoryController {
  final CategoryService _categoryService;

  CategoryController({
    CategoryService? categoryService,
  }) : _categoryService =
            categoryService ?? CategoryService();

  bool get isAuthenticated {
    return _categoryService.isAuthenticated;
  }

  Stream<List<CategoryModel>> get categoriesStream {
    return _categoryService.getCategories();
  }

  Stream<Map<String, int>> get taskCountsStream {
    return _categoryService.getTaskCounts();
  }

  String? validateCategoryName(String name) {
    final String cleanedName = name.trim();

    if (cleanedName.isEmpty) {
      return 'Please enter a category name.';
    }

    if (cleanedName.length > 50) {
      return 'Category names cannot exceed 50 characters.';
    }

    return null;
  }

  Future<void> addCategory(String categoryName) async {
    final String cleanedName = categoryName.trim();

    final String? validationError =
        validateCategoryName(cleanedName);

    if (validationError != null) {
      throw CategoryControllerException(validationError);
    }

    try {
      final bool alreadyExists =
          await _categoryService.categoryNameExists(
        cleanedName,
      );

      if (alreadyExists) {
        throw const CategoryControllerException(
          'A category with this name already exists.',
        );
      }

      await _categoryService.addCategory(
        name: cleanedName,
      );
    } on CategoryControllerException {
      rethrow;
    } on FirebaseAuthException catch (error) {
      throw CategoryControllerException(
        error.message ??
            'Please log in before managing categories.',
      );
    } on FirebaseException catch (error) {
      throw CategoryControllerException(
        error.message ?? 'Unable to add the category.',
      );
    } catch (_) {
      throw const CategoryControllerException(
        'Unable to add the category.',
      );
    }
  }

  Future<void> renameCategory({
    required CategoryModel category,
    required String newName,
  }) async {
    final String cleanedName = newName.trim();

    final String? validationError =
        validateCategoryName(cleanedName);

    if (validationError != null) {
      throw CategoryControllerException(validationError);
    }

    if (cleanedName.toLowerCase() ==
        category.name.trim().toLowerCase()) {
      return;
    }

    try {
      final bool alreadyExists =
          await _categoryService.categoryNameExists(
        cleanedName,
        ignoredCategoryId: category.id,
      );

      if (alreadyExists) {
        throw const CategoryControllerException(
          'A category with this name already exists.',
        );
      }

      await _categoryService.renameCategoryAndTasks(
        category: category,
        newName: cleanedName,
      );
    } on CategoryControllerException {
      rethrow;
    } on FirebaseAuthException catch (error) {
      throw CategoryControllerException(
        error.message ??
            'Please log in before managing categories.',
      );
    } on FirebaseException catch (error) {
      throw CategoryControllerException(
        error.message ?? 'Unable to update the category.',
      );
    } catch (_) {
      throw const CategoryControllerException(
        'Unable to update the category.',
      );
    }
  }

  Future<void> deleteCategory({
    required CategoryModel category,
    required int taskCount,
  }) async {
    if (taskCount > 0) {
      throw CategoryControllerException(
        '"${category.name}" is currently used by '
        '$taskCount ${taskCount == 1 ? 'task' : 'tasks'} '
        'and cannot be deleted.',
      );
    }

    try {
      await _categoryService.deleteCategory(category);
    } on FirebaseAuthException catch (error) {
      throw CategoryControllerException(
        error.message ??
            'Please log in before managing categories.',
      );
    } on FirebaseException catch (error) {
      throw CategoryControllerException(
        error.message ?? 'Unable to delete the category.',
      );
    } catch (_) {
      throw const CategoryControllerException(
        'Unable to delete the category.',
      );
    }
  }
}