import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/profile_model.dart';
import '../services/profile_service.dart';

class ProfileController extends ChangeNotifier {
  final ProfileService _profileService = ProfileService();

  static const List<String> sortingOptions = [
    'Due Date',
    'Priority',
    'Status',
    'Category',
  ];

  StreamSubscription<ProfileModel>? _profileSubscription;

  ProfileModel _profile = ProfileModel.empty();

  bool _isLoading = true;
  String? _errorMessage;
  bool _isDisposed = false;

  ProfileModel get profile {
    return _profile;
  }

  bool get isLoading {
    return _isLoading;
  }

  String? get errorMessage {
    return _errorMessage;
  }

  void start() {
    _profileSubscription = _profileService.watchCurrentUserProfile().listen(
      (profile) {
        final loadedSorting = sortingOptions.contains(
          profile.defaultTaskSorting,
        )
            ? profile.defaultTaskSorting
            : 'Due Date';

        _profile = profile.copyWith(
          defaultTaskSorting: loadedSorting,
        );

        _isLoading = false;
        _errorMessage = null;
        _notify();
      },
      onError: (error) {
        _isLoading = false;
        _errorMessage = error.toString().replaceFirst('Exception: ', '');
        _notify();
      },
    );

    _syncEmailFromAuth();
  }

  Future<void> _syncEmailFromAuth() async {
    try {
      await _profileService.syncEmailFromAuth();
    } catch (_) {
    }
  }

  Future<void> changeUsername(String newUsername) async {
    final trimmedUsername = newUsername.trim();
    final normalizedUsername = trimmedUsername.toLowerCase();

    if (trimmedUsername.isEmpty) {
      throw Exception('Username cannot be empty');
    }

    if (normalizedUsername ==
        _profile.username.trim().toLowerCase()) {
      throw Exception('Please enter a different username');
    }

    bool usernameTaken;

    try {
      usernameTaken = await _profileService.isUsernameTaken(
        trimmedUsername,
      );
    } catch (_) {
      throw Exception('Unable to check username availability');
    }

    if (usernameTaken) {
      throw Exception('Username is already in use');
    }

    final oldProfile = _profile;

    _profile = _profile.copyWith(
      username: trimmedUsername,
    );
    _notify();

    try {
      await _profileService.updateCurrentUserData({
        'username': trimmedUsername,
        'usernameLowercase': normalizedUsername,
      });
    } catch (_) {
      _profile = oldProfile;
      _notify();

      throw Exception('Unable to update username');
    }
  }

  Future<void> updateNotifications(bool value) async {
    final oldProfile = _profile;

    _profile = _profile.copyWith(
      notificationsEnabled: value,
    );
    _notify();

    try {
      await _profileService.updateCurrentUserData({
        'notificationsEnabled': value,
      });
    } catch (error) {
      _profile = oldProfile;
      _notify();
      throw Exception('Unable to update notification setting');
    }
  }

  Future<void> updateDefaultSorting(String value) async {
    if (!sortingOptions.contains(value)) {
      throw Exception('Invalid sorting option');
    }

    final oldProfile = _profile;

    _profile = _profile.copyWith(
      defaultTaskSorting: value,
    );
    _notify();

    try {
      await _profileService.updateCurrentUserData({
        'defaultTaskSorting': value,
      });
    } catch (error) {
      _profile = oldProfile;
      _notify();
      throw Exception('Unable to update default sorting');
    }
  }

  Future<void> sendPasswordResetEmail(String email) async {
    final trimmedEmail = email.trim();

    final currentEmail = FirebaseAuth.instance.currentUser?.email;

    if (!_isValidEmail(trimmedEmail)) {
      throw Exception('Please enter a valid email address');
    }

    if (currentEmail == null ||
        trimmedEmail.toLowerCase() != currentEmail.toLowerCase()) {
      throw Exception('Incorrect email entered');
    }

    try {
      await _profileService.sendPasswordResetEmail(trimmedEmail);
    } on FirebaseAuthException catch (error) {
      throw Exception(_firebaseErrorMessage(error));
    } catch (_) {
      throw Exception('Unable to send password reset email');
    }
  }

  Future<void> changeEmail({
    required String newEmail,
    required String currentPassword,
  }) async {
    final trimmedEmail = newEmail.trim();
    final trimmedPassword = currentPassword.trim();

    if (!_isValidEmail(trimmedEmail)) {
      throw Exception('Please enter a valid new email address');
    }

    if (trimmedPassword.isEmpty) {
      throw Exception('Please enter your current password');
    }

    try {
      await _profileService.reauthenticateCurrentUser(trimmedPassword);

      await _profileService.verifyBeforeUpdateEmail(trimmedEmail);

      await _profileService.updateCurrentUserData({
        'pendingEmail': trimmedEmail,
      });
    } on FirebaseAuthException catch (error) {
      throw Exception(_firebaseErrorMessage(error));
    } catch (_) {
      throw Exception('Unable to update email');
    }
  }

  Future<void> logout() async {
    await _profileService.logout();
  }

  bool _isValidEmail(String email) {
    return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email);
  }

  String _firebaseErrorMessage(FirebaseAuthException error) {
    switch (error.code) {
      case 'wrong-password':
      case 'invalid-credential':
        return 'Current password entered was incorrect';
      case 'email-already-in-use':
        return 'This email is already in use';
      case 'invalid-email':
        return 'Invalid email format';
      case 'requires-recent-login':
        return 'Please re-enter your current password';
      case 'user-not-found':
        return 'No account was found with this email';
      default:
        return error.message ?? 'Something went wrong';
    }
  }

  void _notify() {
    if (!_isDisposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _profileSubscription?.cancel();
    super.dispose();
  }
}