import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TaskController {
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  TaskController({
    FirebaseFirestore? firestore,
    FirebaseAuth? auth,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _auth = auth ?? FirebaseAuth.instance;

  // ============================================================
  // CURRENT USER
  // ============================================================

  User? get currentUser => _auth.currentUser;

  String? get currentUserId => _auth.currentUser?.uid;

  // ============================================================
  // TASK STREAM
  // ============================================================

  Stream<QuerySnapshot<Map<String, dynamic>>> get tasksStream {
    final String? userId = currentUserId;

    if (userId == null) {
      return const Stream.empty();
    }

    return _firestore
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  // ============================================================
  // CATEGORY STREAM
  // ============================================================

  Stream<QuerySnapshot<Map<String, dynamic>>> get categoriesStream {
    final String? userId = currentUserId;

    if (userId == null) {
      return const Stream.empty();
    }

    return _firestore
        .collection('categories')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt')
        .snapshots();
  }

  // ============================================================
  // USER SETTINGS
  // ============================================================

  Stream<DocumentSnapshot<Map<String, dynamic>>>? get settingsStream {
    final User? user = currentUser;

    if (user == null) {
      return null;
    }

    return _firestore
        .collection('userdata')
        .doc(user.uid)
        .snapshots();
  }

  // ============================================================
  // VALIDATION
  // ============================================================

  String? validateTask({
    required String title,
    required String description,
    required String? category,
    required DateTime? dueDateTime,
  }) {
    if (title.trim().isEmpty) {
      return 'Please enter a task title.';
    }

    if (description.trim().isEmpty) {
      return 'Please enter a task description.';
    }

    if (category == null || category.trim().isEmpty) {
      return 'Please select a category.';
    }

    if (dueDateTime == null) {
      return 'Please select a due date and time.';
    }

    if (dueDateTime.isBefore(DateTime.now())) {
      return 'Task date and time cannot be before current time.';
    }

    return null;
  }

  // ============================================================
  // ADD TASK
  // ============================================================

  Future<void> addTask({
    required String title,
    required String description,
    required String category,
    required String priority,
    required DateTime dueDateTime,
    required String reminder,
  }) async {
    final User? user = currentUser;

    if (user == null) {
      throw FirebaseAuthException(
        code: 'not-authenticated',
        message: 'Please log in before creating a task.',
      );
    }

    await _firestore.collection('tasks').add({
      'userId': user.uid,
      'title': title.trim(),
      'description': description.trim(),
      'category': category,
      'priority': priority,
      'dueDate': Timestamp.fromDate(dueDateTime),
      'reminder': reminder,
      'status': 'Pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ============================================================
  // CHECK TASK OWNERSHIP
  // ============================================================

  Future<DocumentReference<Map<String, dynamic>>>
      _ownedTaskReference(String taskId) async {
    final User? user = currentUser;

    if (user == null) {
      throw FirebaseAuthException(
        code: 'not-authenticated',
        message: 'Please log in to manage tasks.',
      );
    }

    final DocumentReference<Map<String, dynamic>> reference =
        _firestore.collection('tasks').doc(taskId);

    final DocumentSnapshot<Map<String, dynamic>> snapshot =
        await reference.get();

    if (!snapshot.exists ||
        snapshot.data()?['userId'] != user.uid) {
      throw FirebaseException(
        plugin: 'cloud_firestore',
        code: 'permission-denied',
        message: 'You can only manage your own tasks.',
      );
    }

    return reference;
  }

  // ============================================================
  // UPDATE TASK
  // ============================================================

  Future<void> updateTask({
    required String taskId,
    required String title,
    required String description,
    required String category,
    required String priority,
    required String reminder,
    required DateTime dueDateTime,
  }) async {
    final DocumentReference<Map<String, dynamic>> reference =
        await _ownedTaskReference(taskId);

    await reference.update({
      'title': title.trim(),
      'description': description.trim(),
      'category': category,
      'priority': priority,
      'reminder': reminder,
      'dueDate': Timestamp.fromDate(dueDateTime),
      'status': 'Pending',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ============================================================
  // DELETE TASK
  // ============================================================

  Future<void> deleteTask(String taskId) async {
    final DocumentReference<Map<String, dynamic>> reference =
        await _ownedTaskReference(taskId);

    await reference.delete();
  }

  // ============================================================
  // MARK TASK AS COMPLETED
  // ============================================================

  Future<void> markTaskAsCompleted(String taskId) async {
    final DocumentReference<Map<String, dynamic>> reference =
        await _ownedTaskReference(taskId);

    await reference.update({
      'status': 'Completed',
      'completedAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ============================================================
  // CHANGE COMPLETED TASK BACK TO PENDING
  // ============================================================

  bool canChangeBackToPending(dynamic dueDate) {
    final DateTime? convertedDate = convertDueDate(dueDate);

    if (convertedDate == null) {
      return false;
    }

    return convertedDate.isAfter(DateTime.now());
  }

  Future<void> changeTaskBackToPending(
    String taskId,
  ) async {
    final DocumentReference<Map<String, dynamic>> reference =
        await _ownedTaskReference(taskId);

    await reference.update({
      'status': 'Pending',
      'completedAt': FieldValue.delete(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ============================================================
  // DATE CONVERSION
  // ============================================================

  DateTime? convertDueDate(dynamic dueDateData) {
    if (dueDateData is Timestamp) {
      return dueDateData.toDate();
    }

    if (dueDateData is DateTime) {
      return dueDateData;
    }

    if (dueDateData is String) {
      final DateTime? normalDate =
          DateTime.tryParse(dueDateData);

      if (normalDate != null) {
        return normalDate;
      }

      return _parseDisplayDate(dueDateData);
    }

    return null;
  }

  DateTime? _parseDisplayDate(String dateText) {
    try {
      final String cleanedDate =
          dateText.trim().replaceAll(',', '');

      final List<String> parts =
          cleanedDate.split(RegExp(r'\s+'));

      if (parts.length < 3) {
        return null;
      }

      final int day = int.parse(parts[0]);
      final int? month = _monthNumber(parts[1]);
      final int year = int.parse(parts[2]);

      if (month == null) {
        return null;
      }

      if (parts.length == 3) {
        return DateTime(
          year,
          month,
          day,
          23,
          59,
          59,
        );
      }

      if (parts.length >= 5) {
        final List<String> timeParts =
            parts[3].split(':');

        if (timeParts.length != 2) {
          return DateTime(
            year,
            month,
            day,
            23,
            59,
            59,
          );
        }

        int hour = int.parse(timeParts[0]);
        final int minute = int.parse(timeParts[1]);

        final String period =
            parts[4].toUpperCase();

        if (period == 'PM' && hour != 12) {
          hour += 12;
        }

        if (period == 'AM' && hour == 12) {
          hour = 0;
        }

        return DateTime(
          year,
          month,
          day,
          hour,
          minute,
        );
      }

      return DateTime(
        year,
        month,
        day,
        23,
        59,
        59,
      );
    } catch (_) {
      return null;
    }
  }

  int? _monthNumber(String month) {
    const Map<String, int> months = {
      'Jan': 1,
      'Feb': 2,
      'Mar': 3,
      'Apr': 4,
      'May': 5,
      'Jun': 6,
      'Jul': 7,
      'Aug': 8,
      'Sep': 9,
      'Oct': 10,
      'Nov': 11,
      'Dec': 12,
    };

    return months[month];
  }

  // ============================================================
  // TASK STATUS
  // ============================================================

  String currentStatus(
    Map<String, dynamic> taskData, {
    DateTime? now,
  }) {
    final DateTime currentTime =
        now ?? DateTime.now();

    final String storedStatus =
        taskData['status']?.toString() ?? 'Pending';

    if (storedStatus.trim().toLowerCase() ==
        'completed') {
      return 'Completed';
    }

    final DateTime? dueDate =
        convertDueDate(taskData['dueDate']);

    if (dueDate != null &&
        (currentTime.isAfter(dueDate) ||
            currentTime.isAtSameMomentAs(dueDate))) {
      return 'Overdue';
    }

    return 'Pending';
  }

  // ============================================================
  // REMINDER
  // ============================================================

  DateTime? getReminderTime({
    required DateTime dueDate,
    required String reminder,
  }) {
    switch (reminder.trim().toLowerCase()) {
      case '10 minutes before':
        return dueDate.subtract(
          const Duration(minutes: 10),
        );

      case '1 hour before':
        return dueDate.subtract(
          const Duration(hours: 1),
        );

      case '1 day before':
        return dueDate.subtract(
          const Duration(days: 1),
        );

      default:
        return null;
    }
  }

  bool isReminderActive(
    Map<String, dynamic> taskData, {
    required bool notificationsEnabled,
    DateTime? now,
  }) {
    if (!notificationsEnabled) {
      return false;
    }

    final DateTime currentTime =
        now ?? DateTime.now();

    final String status = currentStatus(
      taskData,
      now: currentTime,
    ).toLowerCase();

    if (status == 'completed') {
      return false;
    }

    final String reminder =
        taskData['reminder']
                ?.toString()
                .trim()
                .toLowerCase() ??
            'no reminder';

    if (reminder.isEmpty ||
        reminder == 'no reminder') {
      return false;
    }

    final DateTime? dueDate =
        convertDueDate(taskData['dueDate']);

    if (dueDate == null) {
      return false;
    }

    final DateTime? reminderTime =
        getReminderTime(
      dueDate: dueDate,
      reminder: reminder,
    );

    if (reminderTime == null) {
      return false;
    }

    return currentTime.isAtSameMomentAs(reminderTime) ||
        currentTime.isAfter(reminderTime);
  }

  // ============================================================
  // SORTING
  // ============================================================

  int priorityRank(String priority) {
    switch (priority.trim().toLowerCase()) {
      case 'high':
        return 0;

      case 'medium':
        return 1;

      case 'low':
        return 2;

      default:
        return 3;
    }
  }

  int statusRank(String status) {
    switch (status.trim().toLowerCase()) {
      case 'overdue':
        return 0;

      case 'pending':
        return 1;

      case 'completed':
        return 2;

      default:
        return 3;
    }
  }

  DateTime dueDateValue(
    QueryDocumentSnapshot<Map<String, dynamic>> document,
  ) {
    return convertDueDate(
          document.data()['dueDate'],
        ) ??
        DateTime(9999);
  }

  void sortTasks(
    List<QueryDocumentSnapshot<Map<String, dynamic>>> documents, {
    required String defaultSorting,
    required bool notificationsEnabled,
    DateTime? now,
  }) {
    final DateTime currentTime =
        now ?? DateTime.now();

    documents.sort((first, second) {
      final Map<String, dynamic> firstData =
          first.data();

      final Map<String, dynamic> secondData =
          second.data();

      final bool firstHasReminder =
          isReminderActive(
        firstData,
        notificationsEnabled: notificationsEnabled,
        now: currentTime,
      );

      final bool secondHasReminder =
          isReminderActive(
        secondData,
        notificationsEnabled: notificationsEnabled,
        now: currentTime,
      );

      // Active reminders appear first.
      if (firstHasReminder && !secondHasReminder) {
        return -1;
      }

      if (!firstHasReminder && secondHasReminder) {
        return 1;
      }

      switch (defaultSorting) {
        case 'Priority':
          final int firstPriority = priorityRank(
            firstData['priority']?.toString() ?? 'Low',
          );

          final int secondPriority = priorityRank(
            secondData['priority']?.toString() ?? 'Low',
          );

          if (firstPriority != secondPriority) {
            return firstPriority.compareTo(
              secondPriority,
            );
          }

          return dueDateValue(first).compareTo(
            dueDateValue(second),
          );

        case 'Status':
          final int firstStatus = statusRank(
            currentStatus(
              firstData,
              now: currentTime,
            ),
          );

          final int secondStatus = statusRank(
            currentStatus(
              secondData,
              now: currentTime,
            ),
          );

          if (firstStatus != secondStatus) {
            return firstStatus.compareTo(
              secondStatus,
            );
          }

          return dueDateValue(first).compareTo(
            dueDateValue(second),
          );

        case 'Category':
          final String firstCategory =
              firstData['category']
                      ?.toString()
                      .toLowerCase() ??
                  '';

          final String secondCategory =
              secondData['category']
                      ?.toString()
                      .toLowerCase() ??
                  '';

          final int categoryCompare =
              firstCategory.compareTo(secondCategory);

          if (categoryCompare != 0) {
            return categoryCompare;
          }

          return dueDateValue(first).compareTo(
            dueDateValue(second),
          );

        case 'Due Date':
        default:
          return dueDateValue(first).compareTo(
            dueDateValue(second),
          );
      }
    });
  }
}