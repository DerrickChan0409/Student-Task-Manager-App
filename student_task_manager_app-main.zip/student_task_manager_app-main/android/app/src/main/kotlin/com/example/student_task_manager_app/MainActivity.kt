package com.example.student_task_manager_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
